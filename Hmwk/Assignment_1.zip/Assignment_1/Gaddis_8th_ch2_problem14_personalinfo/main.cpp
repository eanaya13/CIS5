
/* 
 * File:   main.cpp
 * Author: Esther
 * Created on June 22, 2022, 9:54 PM
 * Purpose:display personal information
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //initialize variables
    
    //Map inputs to outputs-> The Process
    
    //Display Results
    cout<<"Name: Esther Anaya \n"
            <<"Address: 3470 Brook St Perris, CA 92571 \n"
            <<"Telephone Number: 9513553844 \n"
            <<"College Major: Computer Engineering "<<endl;
    
    //Exit stage right
  
    return 0;
}

