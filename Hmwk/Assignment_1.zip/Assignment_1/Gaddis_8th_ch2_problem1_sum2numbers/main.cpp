
/* 
 * File:   main.cpp
 * Author: Esther
 * Created on June 22, 2022, 9:54 PM
 * Purpose: sum of 2 numbers
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    short op1,op2,result;
    
    //initialize variables
    op1=2;
    op2=3;
    
    //Map inputs to outputs-> The Process
    result=op1+op2;
    
    //Display Results
    cout<<result<<"="<<op1<<"+"<<op2<<endl;
    
    //Exit stage right
  
    return 0;
}

