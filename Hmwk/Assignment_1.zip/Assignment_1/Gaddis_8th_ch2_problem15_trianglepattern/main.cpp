
/* 
 * File:   main.cpp
 * Author: Esther
 * Created on June 27, 2022, 9:54 PM
 * Purpose: Triangle Pattern
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //initialize variables
    
    //Map inputs to outputs-> The Process
    
    //Display Results
    cout<<"   *"<<endl;
cout<<"  ***"<<endl;
cout<<" *****"<<endl;
cout<<"*******"<<endl;

    //Exit stage right
  
    return 0;
}

