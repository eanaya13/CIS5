
/* 
 * File:   main.cpp
 * Author: Esther Anaya
 * Created on July 22, 2022, 9:54 PM
 * Purpose: Card game 21
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>
#include <cstdlib>
#include <fstream>
#include <string>
#include <ctime>

using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes
int conv(char card) //convert card to int
{
    if (card =='2') {
        return 2; }
    if (card =='3') {
        return 3; }
    if (card=='4') {
        return 4; }
    if (card=='5') {
        return 5;}
    if (card=='6') {
        return 6; }
    if (card =='7') {
        return 7; }
    if (card =='8') {
        return 8; }
    if (card =='9') {
        return 9; }    
    if (card =='A') {
        return 1; }
    if (card =='J') {
        return 11; }
    if (card =='Q') {
        return 12; }  
    if (card =='K') {
        return 13; }
    }
    //function to select card at random
    string suit [] = {"Diamonds", "Hearts", "Spades", "Clubs"};
    string face[] = {"2 ", "3 ", "4 ", "5 ", "6 ", "7 ", "8 ", "9 ", "Ace ", "King ", "Queen ", "Jack "};
    
    string getCard()
{
    string card;   
    //declare integer variables that make random values

    int cardValue = rand() % 12;  //creates values between 0 and 11, for randomly determining the face value of a card

    int cardSuite = rand() % 4;  //creates values between 0 and 3, for determining the suit of a card
    
    card += face[cardValue]; //Add the face value to the string "card"
    
    card += suit[cardSuite]; //Add the suit of the card to the string
    
    return card;  //output the string
}
    
 //execution Begins Here
int main(int argc, char** argv) {
 
  void srand (unsigned tm);
    srand (time (0));
    //variables
    char c, x, k, t;
    int p1, cpu, c1, c2,c3,c4, ttl; //user and computer's #s
    string tempc, tempc1, tempc2, tempc3, tempc4, tempc5, tempc6, tempc7, tempc8; //get the card
    string cname; 
    string cpuname;
            
      //Display intro
    cout<<"Welcome to 21!\n";
    cout<<" \n";
    cout<<"How to play: \n";
    cout<<"- you will be given two cards from the deck one at a time \n";
    cout<<"- when given their your cards, check if the sum of the number of both cards is equal to 21 \n";
    cout<<"- card values: numbers equal their respective number, ace = 1, Jack = 11, \n"<<"  "<<"Queen = 12, King = 13 \n";
    cout<<"- if you and the computer both end up with a sum of 21 you will both tie \n";
    cout<<"- if not, the player with the highest number UNDER 21 wins \n";
    cout<<" "<<endl;
    
   
    cout<<"Type 'c' to receive your cards. \n";
            cin>>c;
            
            tempc= getCard();
            tempc1=getCard();
            tempc2=getCard();
            tempc3=getCard();
            tempc4=getCard();
            c1=conv(tempc[0]) + conv(tempc1[0])+ conv(tempc2[0]) + conv(tempc3[0]);
            
            cname=tempc+"\n";
   
            
    cout<<tempc<<", "<<tempc1<<endl;
    cout<<" "<<endl;
    cout<<"Would you like to draw another card? (Y/N)"<<endl;
       cin>>x;
    
    if (x=='Y') {
        cout<<tempc2<<endl;
        cout<<"Would you like to draw another card? (Y/N)"<<endl;
        cin>>k;
             if (k=='Y'){
             cout<<tempc3<<endl;
             cout<<"Would you like to draw another card?(Y/N)"<<endl;
             cin>>t;
                 if (t=='Y') {
                    cout<<tempc4<<endl;
                  }
            }
    }  cout<<"Your total is: "<<c1<<endl;
       cout<<" "<<endl; 
       
   //display computer's turn
       cout<<"Computer's Turn"<<endl;
       cout<<"The computer's cards are: ";
             tempc5=getCard();
            tempc6=getCard();
       cout<<tempc5<<", "<<tempc6<<endl;
            cpu=conv (tempc5[0]) + conv(tempc6[0]);
            cpuname=tempc+"\n";
      
            
                cout<<"The Computer's total is: "<<cpu<<endl;
             
            //display winner
            if (cpu>c1 && cpu<21) {
                cout<<"Computer Wins!"<<endl;
            }
            if (c1>cpu && c1<21) {
                cout<<"You Win!"<<endl;
            }
            if (cpu==21 && c1==21) {
                cout<<"Tie!"<<endl;
            }
            if (cpu==21 && c1!=21) {
                cout<<"Computer Wins!"<<endl;
            }
            if (c1==21 && cpu!=21) {
                cout<<"You Win!"<<endl;
            }
            if (cpu>21 && c1<21) {
                cout<<"You Win!"<<endl;
            }
            if (c1>21 && cpu<21) {
                   cout<<"Computer Wins!"<<endl;
            }      
    //Exit stage right
  
    return 0;
}
   

