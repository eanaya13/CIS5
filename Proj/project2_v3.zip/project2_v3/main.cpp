
/* 
 * File:   main.cpp
 * Author: Esther Anaya
 * Created on July 26, 2022, 1:00 PM
 * Purpose: Card game 21
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>
#include <cstdlib>
#include <fstream>
#include <string>
#include <ctime>

using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays
 
//convert card name to integer
int conv(char card)
{
    if (card =='2') { //set card face number equal to an actual integer value to do calculate sum later 
        return 2; }
    if (card =='3') {
        return 3; }
    if (card=='4') {
        return 4; }
    if (card=='5') {
        return 5;}
    if (card=='6') {
        return 6; }
    if (card =='7') {
        return 7; }
    if (card =='8') {
        return 8; }
    if (card =='9') {
        return 9; }  
    if (card=='1') {
        return 10;}
    if (card =='A') { //ace card equals 1
        return 1; }
    if (card =='J') { //jack card equals 11
        return 11; }
    if (card =='Q') { //queen card equals 12
        return 12; }  
    if (card =='K') { //king card equals 13
        return 13; }
    return 0; 
    }

 //select card at random
//use array of strings
//search function 

    bool search (string *deck,string card) { //search function to see if card was already drawn 
    for (int i=0;i<52;i++) {
        if (deck[i]==card){
            return true;
        }
    }
    return false; 
    }
    
    void remove (string (&deck)[52], string card)  //remove card drawn from deck of 52 cards 
    {
        for (int i=0;i<52;i++) {
            if (deck[i].compare(card) == 0)
            {
                deck[i] = "NULL";
            }
        }
    }
    
    //check if card exists using the search to see if its been used, if not been used display card add it blah blah then after remove card from the deck
    //if reach and doesnt exist use getcard again until finally gets card that hasnt nbeen used
    //if its in there remove it w remove function
    string getCard(string *suit, string *face, string (&deck)[52]) {//string to get randomized card combination of one suit and one face
 
    string card = "";   //card given
   
    //declare integer variables that make random values
    int cardValue = rand() % 12;  //creates values between 0 and 11, for randomly determining the face value of a card

    int cardSuit = rand() % 4;  //creates values between 0 and 3, for determining the suit of a card
    
    card += face[cardValue]; //Add the face value to the string "card"
    
    card += suit[cardSuit]; //Add the suit of the card to the string

    if (search(deck, card))
    {
        remove (deck, card);
    }
    else
    {
        
        while (!search(deck, card))
        {
             card = "";   //card given

            //declare integer variables that make random values
            cardValue = rand() % 12;  //creates values between 0 and 11, for randomly determining the face value of a card

            cardSuit = rand() % 4;  //creates values between 0 and 3, for determining the suit of a card

            card += face[cardValue]; //Add the face value to the string "card"

            card += suit[cardSuit];
         }
         
    }
    
    
    
    return card;  //output string 
}
    
 //execution Begins Here
int main(int argc, char** argv) {
   //function to calculate if # is under, over or equal to 21 
    //declare variables
    string suit[4] = {"Diamonds", "Hearts", "Spades", "Clubs"}; //suit names
    string face[13] = {"2 ", "3 ", "4 ", "5 ", "6 ", "7 ", "8 ", "9 ","10 ", "Ace ", "King ", "Queen ", "Jack "}; 
    //suit face values to combine
    string deck[52];
    int current = 0; 
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 13; j++)
        {
            deck[current] = face[j] + suit[i];
            current += 1; 
        }
    }
    
   
    char c, //input from user to get their first two cards dealt
         x; //input from user to say if they want to draw more cards
    string tempc; //get the card
    string cname; //card name for player 
    string cpuname; //computer face of card name
    unsigned tm; //time
    float plyrttl=0 ; //player total #s 
    int cputtl = 0; //computer's sum of all cards
    bool addcard; //boolean for drawing another card
    
       //time
    void srand (unsigned tm);
    srand (time (0));
    
      //Display intro
    cout<<"Welcome to 21!\n";
    cout<<" \n";
    
    //display rules
    cout<<"How to play: \n";
    cout<<"- you will be given two cards from the deck one at a time \n";
    cout<<"- when given your cards, check if the sum of your cards is equal to 21 \n";
    cout<<"- card values: numbers equal their respective number, ace = 1, Jack = 11, \n"<<"  "<<"Queen = 12, King = 13 \n";
    cout<<"- if your sum is under 21, you can keep drawing another card"<<endl;
    cout<<"- if you and the computer both end up with a sum of 21 you will both tie \n";
    cout<<"- if not, the player with the highest number UNDER 21 wins \n";
    cout<<" "<<endl;
    
//player gets first two cards
    cout<<"Type 'c' to receive your cards. \n";
    cin>>c;
            tempc= getCard(suit, face, deck); //value that changes because each card is uniquely randomized
            plyrttl+=conv(tempc[0]); //total that adds even with new cards, uses only number values no suit names
            cname=tempc+"\n"; //name with suit and face of card
   
    cout<<tempc<<", ";
    
    tempc=getCard(suit, face, deck); //call again for new randomized card value
    plyrttl+=conv(tempc[0]);
    cname+=tempc+"\n";
    
    cout<<tempc<<endl;
    cout<<" "<<endl;
    cout<<"Would you like to draw another card? (Y/N)"<<endl; //option to draw more cards if player wants to
       cin>>x;
    
       
    while (x=='Y')  { //draw card
         tempc=getCard (suit, face, deck);
         plyrttl+=conv(tempc[0]);
         cname+=tempc+"\n";
         cout<<tempc<<endl;
        cout<<"Would you like to draw another card? (Y/N)"<<endl;
        cin>>x;
    } 
    
    
       cout<<"Your total is: "<<setw(1)<<setprecision(5)<<plyrttl<<endl; //displays player's total at end
       cout<<" "<<endl; 
      
   //display computer's turn
       cout<<"Dealer's Turn!"<<endl; //displays computer's turn
       cout<<"The Dealer's cards are: ";
        tempc=getCard(suit, face, deck); //display computer's cards
       cout<<tempc<<", "; 
       
        tempc=getCard(suit, face, deck);
        cputtl+=conv(tempc[0]);
        cpuname+=tempc+"\n";
         
       cout<<tempc<<endl;
       
       if (cputtl<18) { //if computer's total is under 18, draw more cards since it still has a chance to get 21 without going too much higher
           addcard=true;
       }
       else {
           addcard=false; //if computer's total is not under 18 don't draw another card since it would be hard to get a sum of 21 or lower
       }
               
       while (addcard==true)  { //when computer's total is under 18, draw card
         cout<<"Dealer will draw another card."<<endl;
        
         tempc=getCard(suit, face, deck); //call again for new card
         cputtl+=conv(tempc[0]);
         cpuname+=tempc+"\n";
         cout<<tempc<<endl; 
       
         if (cputtl>=18) {
                addcard=false; } 
       }

       if (addcard==false) {
       cout<<"The Dealer's total is: "<<cputtl<<endl;
       cout<<" "<<endl; }
       
       
            //display winner
            if (cputtl>plyrttl && cputtl<21) {
                cout<<"Dealer Wins!"<<endl;
            }
       else if (plyrttl>cputtl && plyrttl<21) {
                cout<<"You Win!"<<endl;
            }
       else if (cputtl==21 && plyrttl!=21) {
                cout<<"Dealer Wins!"<<endl;
            }
       else if (plyrttl==21 && cputtl!=21) {
                cout<<"You Win!"<<endl;
            }
       else if (cputtl>21 && plyrttl<21) {
                cout<<"You Win!"<<endl;
            }
       else if (plyrttl>21 && cputtl<21) {
                   cout<<"Dealer Wins!"<<endl;
            }   
       else if (plyrttl==cputtl ) {
                cout<<"Tie!"<<endl;
            }
            else {
               cout<<"You both lose!"<<endl;
            }
    //Exit stage right
                
    return 0;
}
   
